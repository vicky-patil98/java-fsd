package com.assistedpract.practice2.p08;

public class P08_1 
{  
    String name; 
    String color; 
    int price; 
 
    public P08_1(String name, String color, int price) {
		super();
		this.name = name;
		this.color = color;
		this.price = price;
	}
    
    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}


	@Override
    public String toString() 
    { 
        return("Car Name: "+ this.getName()+ "\nColor : " + this.getColor()+"\nPrice : " + this.getPrice()+"."); 
    } 
    public static void main(String[] args) 
    { 
    	P08_1 scott = new P08_1("Kia Seltos","Matalic Black", 2500000); 
        System.out.println(scott.toString()); 
    } 
}
