package com.assistedpract.practice2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

class FileException extends Exception{
    FileException(String message, Throwable th){
        super(message,th);
    }
}

public class P06 {
    public static void main(String[] main){
        FileInputStream myFile;

        try {
            myFile = new FileInputStream("E://myFolder//tempFile.txt");
        }catch (FileNotFoundException e) {

            try{
                throw new FileException("PLease check File Name or path", e);
            }catch(Exception fileE){
                System.out.println(fileE.getMessage());
            }
       }
    }
}

