package com.assistedpract.practice2.p01;

class MyRunnableThread implements Runnable{

	int n;
	public MyRunnableThread(int n) {
		this.n = n;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Thread t = Thread.currentThread();
        System.out.println (t.getName () + "Thread started");
		for (int i = 1;i<=n;i++)
		{
			System.out.println(t.getName()+" Thread Value=>"+i);
			try {
				Thread.sleep(1000);
			}
			catch (InterruptedException e)
			{
				
			}
		}
		
        System.out.println (t.getName()+" is terminated...");
	}
	
}
public class P01_2 {

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		System.out.println("Main Thread Started");
		MyRunnableThread mrt = new MyRunnableThread(5);
		Thread t2 = new Thread(mrt,"Child Thread");
		
		t2.start();
		
        for (int i = 1; i <= 5; i++)
        {
            System.out.println ("Main Thread Value:" + i);
            try
            {
               Thread.sleep (1000);
            }
            catch (InterruptedException ie)
            {
            }
        }
		
        System.out.println ("Main thread is terminated...");
	}

}
