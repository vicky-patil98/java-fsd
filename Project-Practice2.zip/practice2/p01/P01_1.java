package com.assistedpract.practice2.p01;


class MyThread extends Thread
{
	public void run()
	{
		System.out.println(Thread.currentThread().getName()+" is running");
	}
}
public class P01_1 {
	
	public static void main(String[] args) {
		MyThread th = new MyThread();
		Thread t = new Thread(th);
		
		t.start	();
		
	}

}
