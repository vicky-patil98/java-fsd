package com.assistedpract.practice2.p07;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class P07_3 {

    public static void main(String[] args) {
        File file = new File("myfile.txt");

        FileWriter writer = null;
        try {
            writer = new FileWriter(file);

            writer.write("This is the new content of the file.");

            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("The file has been updated.");
    }
}