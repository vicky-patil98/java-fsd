package com.assistedpract.practice2.p07;

import java.io.*;

//Main class
public class P07_2 {

	// main driver method
	public static void main(String[] args) throws Exception
	{
		File file = new File("myfile.txt");

		BufferedReader br = new BufferedReader(new FileReader(file));

		String st;

		while ((st = br.readLine()) != null)
			System.out.println(st);
	}
}

