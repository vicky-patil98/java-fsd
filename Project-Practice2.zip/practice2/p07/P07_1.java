package com.assistedpract.practice2.p07;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class P07_1 {

    public static void main(String[] args) throws IOException {
        File file = new File("myfile.txt");

        if (file.createNewFile()) {
            System.out.println("File created: " + file.getName());
        } else {
            System.out.println("File already exists.");
        }
        
        //Write Content
        FileWriter writer = new FileWriter(file);
        writer.write("Test data");
        writer.close();

    }
}
