package com.assistedpract.practice2.p05;

public class P05_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20, b=0;
		
		try {
			if(b==0)
			{
				throw new ArithmeticException("Can not devide by zero");
			}
			else{
				int result = a/b;
				System.out.println("Result is "+result);
			}
		}
		catch (ArithmeticException e)
		{
			System.out.println("Error : "+e.getMessage());
		}

	}

}
