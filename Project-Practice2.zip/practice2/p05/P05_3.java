package com.assistedpract.practice2.p05;

public class P05_3 {
	
	public void ageCheck(int age) throws ArithmeticException
	{
		if (age < 18)
		{
			throw new ArithmeticException("Not a valid age");
		}
		else {
			System.out.println("Eligible for vote");
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		P05_3 obj = new P05_3();
		try {
			obj.ageCheck(20);
			obj.ageCheck(15);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		finally {
			System.out.println("Program exited");
		}

	}

}
