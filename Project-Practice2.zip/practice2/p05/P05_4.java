package com.assistedpract.practice2.p05;

class customException1 extends Exception
{
	public customException1(String message){
		super(message);
	}
}
public class P05_4 {
	
	public void ageCheck(int age) throws customException1
	{
		if (age < 18)
		{
			throw new customException1("Not a valid age");
		}
		else {
			System.out.println("Eligible for vote");
		}
		
	}

	public static void main(String[] args){
		// TODO Auto-generated method stub
		
		P05_4 obj = new P05_4();
		try {
			obj.ageCheck(20);
			obj.ageCheck(15);
		}
		catch(customException1 e)
		{
			System.out.println("Custom Exception : "+e.getMessage());
		}

	}


}

