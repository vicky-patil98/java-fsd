package com.example.utils;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


public class NumberUtilsTest {

    @Test
    void testIsEven() {
        assertTrue(NumberUtils.isEven(2));
        assertFalse(NumberUtils.isEven(3));
    }
}