package com.example.utils;

public class NumberUtils {

	public static boolean isEven(int number) {
        return number % 2 == 0;
    }
}
