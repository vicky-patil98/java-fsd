package com.example.tests;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnJre;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.EnabledOnJre;

public class ConditionalTests {

    @Test
    @EnabledOnJre(JRE.JAVA_8)
    void testOnJava8() {
        // Test that should only run on Java 8
        assertTrue(true);
    }

    @Test
    @DisabledOnJre(JRE.JAVA_8)
    void testNotOnJava8() {
        // Test that should not run on Java 8
        assertTrue(true);
    }
}

