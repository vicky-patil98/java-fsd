package com.example.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import java.util.stream.Stream;

public class DynamicTests {

    @TestFactory
    Stream<DynamicTest> dynamicTestsFromStream() {
        return Stream.of("apple", "banana", "orange")
                     .map(fruit ->
                         DynamicTest.dynamicTest("Test " + fruit, () -> {
                             assertTrue(fruit.length() > 0);
                         })
                     );
    }
}

