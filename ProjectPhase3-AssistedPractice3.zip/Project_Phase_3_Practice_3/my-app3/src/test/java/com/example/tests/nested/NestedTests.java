package com.example.tests.nested;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

public class NestedTests {

    @Nested
    class InnerTests {
        @Test
        void testInner1() {
            assertTrue(true);
        }

        @Test
        void testInner2() {
            assertFalse(false);
        }
    }

    @Test
    void testOuter() {
        assertEquals(2, 1 + 1);
    }
}
