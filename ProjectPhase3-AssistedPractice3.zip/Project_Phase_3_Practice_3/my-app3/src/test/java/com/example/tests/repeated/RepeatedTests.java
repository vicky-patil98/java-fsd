package com.example.tests.repeated;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.RepeatedTest;

public class RepeatedTests {

    @RepeatedTest(3)
    void testRepeated() {
        assertEquals(2, 1 + 1);
    }
}
