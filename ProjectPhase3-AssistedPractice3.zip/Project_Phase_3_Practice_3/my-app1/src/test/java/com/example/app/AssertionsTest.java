package com.example.app;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AssertionsTest {

	@Test
    void testAssertions() {
        // Test equality
        assertEquals(2, 1 + 1);

        // Test truthiness
        assertTrue(1 < 2);

        // Test not null
        assertNotNull("Hello");

        // Test arrays equality
        assertArrayEquals(new int[]{1, 2, 3}, new int[]{1, 2, 3});
	}

}
