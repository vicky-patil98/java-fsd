package com.example.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class DependencyInjectionTest {

    @Mock
    private MyDependency myDependency;

    @Test
    void testDependencyInjected() {
        assertNotNull(myDependency);
        // Use myDependency in assertions or other testing logic
    }
}
