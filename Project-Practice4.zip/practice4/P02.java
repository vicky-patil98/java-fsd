package com.assistedpract.practice4;

import java.util.Scanner;

//binary search
public class P02 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an array of integers
        int[] arr = {10, 20, 30, 40, 50};

        // Get the element to search for
        System.out.println("Enter the element to search for: ");
        int key = scanner.nextInt();

        // Perform binary search
        int index = binarySearch(arr, key);

        // Print the result
        if (index == -1) {
            System.out.println("Element not found");
        } else {
            System.out.println("Element found at index: " + index);
        }
    }

    public static int binarySearch(int[] arr, int key) {
        int low = 0;
        int high = arr.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;

            if (arr[mid] == key) {
                return mid;
            } else if (arr[mid] < key) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1;
    }
}
