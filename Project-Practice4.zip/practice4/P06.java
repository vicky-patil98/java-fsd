package com.assistedpract.practice4;

//Insertion Sort
public class P06 {

    public static void main(String[] args) {
        int[] arr = {9,12,3,21,44};

        // Sort the array using insertion sort
        insertionSort(arr);

        // Print the sorted array
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);
        }
    }

    public static void insertionSort(int[] arr) {
        for (int i = 1; i < arr.length; i++) {
            int current = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > current) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = current;
        }
    }
}
